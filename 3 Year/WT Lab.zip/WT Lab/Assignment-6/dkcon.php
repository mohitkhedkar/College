<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="assignment-6";

$mysqli = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

?>

