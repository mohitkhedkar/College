<html>
<head>
<h2><center>Login Page</h1>
<title>Login</title>
</head>
<body><center>
<form action="dkadd.php" method="post">
<table>
	<tr><th>Name</th><td><input type="text" name="name" required></td></tr>
	<th>Age</th><td><input type="number" name="age" required></td></tr>
	<th>Country</th><td><input type="text" name="country" required></td></tr>
	<th><input type="submit" value="submit" name="Submit"></th>
<table>
</form>
</body>
</html>
