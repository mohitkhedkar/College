### Assignment-1: Installation  and  Configuration  of  Web  Application  Servers  Tomcat.

The Apache Tomcat software is an open source implementation of the Jakarta Servlet, Jakarta Server Pages, Jakarta Expression Language, Jakarta WebSocket, Jakarta Annotations and Jakarta Authentication specifications.

[Download here](https://tomcat.apache.org/)