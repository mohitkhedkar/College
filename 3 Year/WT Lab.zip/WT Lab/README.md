#  Web Technology Lab (WT Lab).

## List of Assignments

### Assignment-1:
- [x] Installation  and  Configuration  of  Web  Application  Servers  Tomcat.

### Assignment-2: 
- [x] Design  and  develop  any  suitable  web  application  using  HTML,  CSS. 
    write a program to design registration form for students by HTML and CSS.

### Assignment-3: 
- [x] Design  and  develop  any  suitable  web  application  using XML & CSS. Write a program to design book catalog by using XML and CSS to display tile, author, price and year of the book.

### Assignment-4:
- [x] Write a program to design registration form for students by using HTML, CSS & Java Script and perform following validations: all fields mandatory, phone number and email address validation

### Assignment-5:
- [ ] Write a program to design and Build Student Login Page using JSP, Servlet and MySQL

### Assignment-6:
- [x] Write a program to design and develop dynamic web application using PHP and MySQL as a back-end for employee data with insert and view operations.

### Assignment-7:
- [x] Write a program to design and develop dynamic web application using PHP, AJAX and MySQL as a back-end for employee data with insert and view operations

### Assignment-8:
- [x] Write a program for Create an application for Bill Payment Record using AngularJS.

### Assignment 9:
- [ ] Write a program to Design, Develop & Deploy web application using Bootstrap

### Assignment 10:
- [x] Design, Develop & Deploy web application using wordpress using XAMPP Server

---
## Extra Assignments:
### Assignment 11:
- [ ] Create a College Website using HTML5, CSS3, and JavaScript.

### Assignment 12:
- [ ] Create a Web Application using Macromedia Dream Weaver-8